"""
学生成绩分析工具 - 精简专业版
功能：统计分析、等级划分、异常检测、基础可视化
"""

import statistics
import json
import os
from typing import List, Dict, Tuple
from collections import Counter

class GradeAnalyzer:
    """精简版成绩分析器"""
    
    def __init__(self, grade_scale: Dict = None):
        self.grades: List[float] = []
        self.grade_scale = grade_scale or {
            "A": 90, "B": 80, "C": 70, "D": 60, "F": 0
        }
    
    def load_grades(self, grades: List[float]) -> None:
        """加载成绩列表"""
        self.grades = [float(g) for g in grades if 0 <= g <= 100]
        print(f"✅ 加载 {len(self.grades)} 条成绩记录")
    
    def basic_stats(self) -> Dict:
        """计算基本统计量"""
        if not self.grades:
            return {"error": "无数据"}
        
        return {
            "count": len(self.grades),
            "mean": round(statistics.mean(self.grades), 2),
            "median": round(statistics.median(self.grades), 2),
            "std_dev": round(statistics.stdev(self.grades), 2) if len(self.grades) > 1 else 0,
            "min": round(min(self.grades), 2),
            "max": round(max(self.grades), 2),
            "range": round(max(self.grades) - min(self.grades), 2),
        }
    
    def grade_distribution(self) -> Dict:
        """分析成绩分布"""
        distribution = {"A": 0, "B": 0, "C": 0, "D": 0, "F": 0}
        
        for grade in self.grades:
            if grade >= self.grade_scale["A"]:
                distribution["A"] += 1
            elif grade >= self.grade_scale["B"]:
                distribution["B"] += 1
            elif grade >= self.grade_scale["C"]:
                distribution["C"] += 1
            elif grade >= self.grade_scale["D"]:
                distribution["D"] += 1
            else:
                distribution["F"] += 1
        
        # 转换为百分比
        total = len(self.grades)
        percentage = {k: round(v/total*100, 1) for k, v in distribution.items()}
        
        return {
            "count": distribution,
            "percentage": percentage
        }
    
    def detect_outliers(self) -> List[float]:
        """检测异常值（简单IQR方法）"""
        if len(self.grades) < 4:
            return []
        
        sorted_grades = sorted(self.grades)
        q1 = sorted_grades[len(sorted_grades)//4]
        q3 = sorted_grades[3*len(sorted_grades)//4]
        iqr = q3 - q1
        
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        
        return [g for g in self.grades if g < lower_bound or g > upper_bound]
    
    def generate_report(self) -> str:
        """生成分析报告"""
        if not self.grades:
            return "无数据可供分析"
        
        stats = self.basic_stats()
        dist = self.grade_distribution()
        outliers = self.detect_outliers()
        
        report = []
        report.append("=" * 50)
        report.append("学生成绩分析报告".center(50))
        report.append("=" * 50)
        report.append(f"\n📊 基本统计")
        report.append(f"  学生总数: {stats['count']}")
        report.append(f"  平均分: {stats['mean']}")
        report.append(f"  中位数: {stats['median']}")
        report.append(f"  标准差: {stats['std_dev']}")
        report.append(f"  最低分: {stats['min']}")
        report.append(f"  最高分: {stats['max']}")
        
        report.append(f"\n📈 成绩分布")
        for grade, count in dist['count'].items():
            percent = dist['percentage'][grade]
            report.append(f"  {grade}等: {count}人 ({percent}%)")
        
        if outliers:
            report.append(f"\n⚠️  异常值检测")
            report.append(f"  发现 {len(outliers)} 个异常值: {outliers}")
        
        report.append(f"\n💡 教学建议")
        if stats['mean'] >= 80:
            report.append("  班级整体表现优秀，继续保持！")
        elif stats['mean'] >= 70:
            report.append("  班级表现良好，可加强薄弱环节")
        else:
            report.append("  需要加强教学，重点关注基础薄弱学生")
        
        if dist['percentage']['F'] > 15:
            report.append("  不及格率较高，建议开展补习")
        
        report.append("\n" + "=" * 50)
        
        return "\n".join(report)
    
    def save_results(self, filename: str = "grade_analysis.json") -> bool:
        """保存分析结果"""
        try:
            results = {
                "statistics": self.basic_stats(),
                "distribution": self.grade_distribution(),
                "outliers": self.detect_outliers(),
                "grade_scale": self.grade_scale
            }
            
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            
            print(f"✅ 结果已保存至: {filename}")
            return True
        except Exception as e:
            print(f"❌ 保存失败: {e}")
            return False


def simple_visualization(grades: List[float]) -> None:
    """简单文本可视化"""
    if not grades:
        return
    
    print("\n📊 简单可视化")
    print("-" * 40)
    
    # 创建10分区间
    bins = {}
    for i in range(0, 101, 10):
        bin_range = f"{i:3d}-{i+9:3d}"
        bins[bin_range] = 0
    
    # 统计每个区间的人数
    for grade in grades:
        bin_key = f"{int(grade//10*10):3d}-{int(grade//10*10+9):3d}"
        bins[bin_key] = bins.get(bin_key, 0) + 1
    
    # 显示直方图
    for bin_range, count in bins.items():
        bar = "█" * (count * 30 // len(grades) + 1)  # 缩放显示
        print(f"{bin_range}: {bar} ({count}人)")


def main():
    """主程序"""
    print("📊 学生成绩分析工具")
    print("-" * 40)
    
    # 创建分析器
    analyzer = GradeAnalyzer()
    
    # 示例数据或用户输入
    use_example = input("使用示例数据？(y/n): ").lower() == 'y'
    
    if use_example:
        # 示例数据
        example_grades = [85, 92, 78, 65, 95, 88, 72, 60, 82, 79, 45, 100, 67, 74, 81]
        analyzer.load_grades(example_grades)
        print("使用示例数据:", example_grades)
    else:
        # 用户输入
        grades_input = input("请输入成绩，用空格分隔: ")
        grades = [float(g.strip()) for g in grades_input.split() if g.strip().replace('.', '').isdigit()]
        analyzer.load_grades(grades)
    
    if not analyzer.grades:
        print("❌ 无有效数据")
        return
    
    # 显示分析结果
    print("\n" + analyzer.generate_report())
    
    # 简单可视化
    simple_visualization(analyzer.grades)
    
    # 保存结果
    save = input("\n保存分析结果？(y/n): ").lower() == 'y'
    if save:
        analyzer.save_results()


if __name__ == "__main__":
    main()