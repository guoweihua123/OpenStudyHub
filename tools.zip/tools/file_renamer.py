"""
FileBatchRenamer - 专业级文件批量重命名工具
版本: 2.0
作者: OpenStudyHub 工具模块
功能: 提供多种重命名模式，支持批量操作、预览、回滚和日志记录
"""

import os
import sys
import re
import shutil
import json
import datetime
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import argparse

# 颜色输出支持
class Colors:
    """终端颜色输出"""
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

class FileBatchRenamer:
    """专业文件批量重命名器"""
    
    def __init__(self):
        self.rename_history = []
        self.log_file = "rename_log.json"
        self.preview_mode = False
        self.dry_run = False
        
    def load_config(self, config_path: str = "renamer_config.json") -> Dict:
        """加载配置文件"""
        default_config = {
            "default_prefix": "file_",
            "default_suffix": "",
            "keep_original_extension": True,
            "backup_before_rename": True,
            "auto_create_backup": True,
            "log_level": "INFO",
            "date_format": "YYYYMMDD_HHMMSS",
            "auto_increment_digits": 3,
            "exclude_patterns": [".DS_Store", "Thumbs.db", "desktop.ini"],
            "supported_extensions": [".txt", ".pdf", ".doc", ".docx", ".xls", 
                                    ".xlsx", ".jpg", ".png", ".mp4", ".mp3"]
        }
        
        try:
            if os.path.exists(config_path):
                with open(config_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            print(f"{Colors.WARNING}⚠️  配置文件加载失败，使用默认配置: {e}{Colors.ENDC}")
        
        return default_config
    
    def save_log(self, operation_type: str, details: Dict) -> None:
        """保存操作日志"""
        log_entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "operation": operation_type,
            "details": details,
            "success": True
        }
        
        try:
            if os.path.exists(self.log_file):
                with open(self.log_file, 'r', encoding='utf-8') as f:
                    log_data = json.load(f)
            else:
                log_data = {"operations": []}
            
            log_data["operations"].append(log_entry)
            
            with open(self.log_file, 'w', encoding='utf-8') as f:
                json.dump(log_data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"{Colors.WARNING}⚠️  日志保存失败: {e}{Colors.ENDC}")
    
    def get_files_list(self, folder_path: str, recursive: bool = False, 
                      extensions: Optional[List[str]] = None) -> List[Path]:
        """获取文件列表（支持递归和扩展名过滤）"""
        folder = Path(folder_path)
        
        if not folder.exists():
            raise FileNotFoundError(f"文件夹不存在: {folder_path}")
        
        if not folder.is_dir():
            raise NotADirectoryError(f"路径不是文件夹: {folder_path}")
        
        files = []
        
        if recursive:
            # 递归获取所有文件
            pattern = "**/*" if not extensions else f"**/*[{''.join(extensions)}]"
            files = list(folder.glob(pattern))
        else:
            # 仅当前目录
            files = list(folder.iterdir())
        
        # 过滤：只要文件，不要文件夹
        files = [f for f in files if f.is_file()]
        
        # 按名称排序
        files.sort()
        
        return files
    
    def preview_rename(self, files: List[Path], rename_pattern: str, 
                      start_num: int = 1, prefix: str = "", 
                      suffix: str = "", replace_old: str = "", 
                      replace_new: str = "") -> List[Tuple[Path, str]]:
        """预览重命名结果"""
        preview_results = []
        
        for i, file_path in enumerate(files, start=start_num):
            original_name = file_path.stem  # 不带扩展名的文件名
            extension = file_path.suffix    # 扩展名
            
            # 应用重命名规则
            if rename_pattern == "sequential":
                # 序列号模式: prefix_001suffix.ext
                new_name = f"{prefix}{i:03d}{suffix}{extension}"
            elif rename_pattern == "date_prefix":
                # 日期前缀模式: YYYYMMDD_filename.ext
                date_str = datetime.datetime.now().strftime("%Y%m%d")
                new_name = f"{date_str}_{original_name}{extension}"
            elif rename_pattern == "replace":
                # 替换模式
                new_name = f"{original_name.replace(replace_old, replace_new)}{extension}"
            elif rename_pattern == "lowercase":
                # 全小写
                new_name = f"{original_name.lower()}{extension}"
            elif rename_pattern == "uppercase":
                # 全大写
                new_name = f"{original_name.upper()}{extension}"
            elif rename_pattern == "remove_spaces":
                # 移除空格
                new_name = f"{original_name.replace(' ', '_')}{extension}"
            elif rename_pattern == "custom":
                # 自定义模式（使用模板）
                template = prefix or "{name}_{num:03d}{ext}"
                new_name = template.format(
                    name=original_name,
                    num=i,
                    ext=extension,
                    date=datetime.datetime.now().strftime("%Y%m%d"),
                    time=datetime.datetime.now().strftime("%H%M%S")
                )
            else:
                # 默认：仅添加前缀后缀
                new_name = f"{prefix}{original_name}{suffix}{extension}"
            
            preview_results.append((file_path, new_name))
        
        return preview_results
    
    def execute_rename(self, preview_results: List[Tuple[Path, str]], 
                      backup: bool = True) -> Dict[str, any]:
        """执行实际的重命名操作"""
        results = {
            "success": [],
            "failed": [],
            "skipped": [],
            "backup_path": None
        }
        
        # 创建备份文件夹
        if backup:
            backup_dir = Path("rename_backup") / datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_dir.mkdir(parents=True, exist_ok=True)
            results["backup_path"] = str(backup_dir)
        
        for original_path, new_name in preview_results:
            try:
                # 构建新路径
                new_path = original_path.parent / new_name
                
                # 检查新文件是否已存在
                if new_path.exists():
                    results["skipped"].append({
                        "original": str(original_path),
                        "new": str(new_path),
                        "reason": "目标文件已存在"
                    })
                    continue
                
                # 创建备份
                if backup and results["backup_path"]:
                    backup_file = Path(results["backup_path"]) / original_path.name
                    shutil.copy2(original_path, backup_file)
                
                if self.dry_run:
                    # 模拟运行，不实际重命名
                    print(f"{Colors.OKBLUE}[模拟] {original_path.name} -> {new_name}{Colors.ENDC}")
                    results["success"].append({
                        "original": str(original_path),
                        "new": str(new_path),
                        "backed_up": backup
                    })
                else:
                    # 实际重命名
                    original_path.rename(new_path)
                    print(f"{Colors.OKGREEN}✓ 重命名: {original_path.name} -> {new_name}{Colors.ENDC}")
                    
                    results["success"].append({
                        "original": str(original_path),
                        "new": str(new_path),
                        "backed_up": backup
                    })
                    
                    # 记录到历史
                    self.rename_history.append({
                        "timestamp": datetime.datetime.now().isoformat(),
                        "original": str(original_path),
                        "new": str(new_path)
                    })
            
            except PermissionError:
                error_msg = "权限不足"
                print(f"{Colors.FAIL}✗ 失败: {original_path.name} -> {error_msg}{Colors.ENDC}")
                results["failed"].append({
                    "original": str(original_path),
                    "error": error_msg
                })
            except Exception as e:
                error_msg = str(e)
                print(f"{Colors.FAIL}✗ 失败: {original_path.name} -> {error_msg}{Colors.ENDC}")
                results["failed"].append({
                    "original": str(original_path),
                    "error": error_msg
                })
        
        # 保存操作日志
        self.save_log("batch_rename", {
            "total_files": len(preview_results),
            "successful": len(results["success"]),
            "failed": len(results["failed"]),
            "skipped": len(results["skipped"]),
            "backup_path": results["backup_path"]
        })
        
        return results
    
    def undo_last_rename(self) -> bool:
        """撤销上一次重命名操作"""
        if not self.rename_history:
            print(f"{Colors.WARNING}⚠️  没有可撤销的操作{Colors.ENDC}")
            return False
        
        try:
            last_operation = self.rename_history[-1]
            original_path = Path(last_operation["original"])
            new_path = Path(last_operation["new"])
            
            if new_path.exists():
                new_path.rename(original_path)
                print(f"{Colors.OKGREEN}✓ 已撤销: {new_path.name} -> {original_path.name}{Colors.ENDC}")
                
                # 从历史记录中移除
                self.rename_history.pop()
                
                # 保存撤销日志
                self.save_log("undo_rename", {
                    "original": str(original_path),
                    "new": str(new_path),
                    "timestamp": last_operation["timestamp"]
                })
                
                return True
            else:
                print(f"{Colors.FAIL}✗ 目标文件不存在，无法撤销{Colors.ENDC}")
                return False
                
        except Exception as e:
            print(f"{Colors.FAIL}✗ 撤销失败: {e}{Colors.ENDC}")
            return False
    
    def find_duplicate_names(self, folder_path: str) -> List[List[str]]:
        """查找重复文件名"""
        folder = Path(folder_path)
        name_dict = {}
        
        for file_path in folder.rglob("*"):
            if file_path.is_file():
                name = file_path.name.lower()
                if name not in name_dict:
                    name_dict[name] = []
                name_dict[name].append(str(file_path))
        
        # 返回有重复的文件名
        return [paths for paths in name_dict.values() if len(paths) > 1]
    
    def clean_filename(self, filename: str) -> str:
        """清理文件名中的非法字符"""
        # Windows 文件名非法字符: \ / : * ? " < > |
        illegal_chars = r'[\\/*?:"<>|]'
        clean_name = re.sub(illegal_chars, '_', filename)
        
        # 移除首尾空格和点
        clean_name = clean_name.strip().strip('.')
        
        # 限制长度（Windows 最大 255 字符，但建议更短）
        if len(clean_name) > 200:
            name_part = clean_name[:150]
            ext_part = clean_name[150:] if '.' not in clean_name else ''
            clean_name = name_part + ext_part
        
        return clean_name
    
    def print_summary(self, results: Dict[str, any]) -> None:
        """打印操作总结"""
        print(f"\n{Colors.BOLD}{'='*50}{Colors.ENDC}")
        print(f"{Colors.HEADER}📊 重命名操作总结{Colors.ENDC}")
        print(f"{Colors.BOLD}{'='*50}{Colors.ENDC}")
        
        total = len(results.get("success", [])) + len(results.get("failed", [])) + len(results.get("skipped", []))
        
        print(f"📁 处理文件总数: {total}")
        print(f"{Colors.OKGREEN}✅ 成功: {len(results.get('success', []))}{Colors.ENDC}")
        print(f"{Colors.FAIL}❌ 失败: {len(results.get('failed', []))}{Colors.ENDC}")
        print(f"{Colors.WARNING}⚠️  跳过: {len(results.get('skipped', []))}{Colors.ENDC}")
        
        if results.get("backup_path"):
            print(f"💾 备份位置: {results['backup_path']}")
        
        if results.get("failed"):
            print(f"\n{Colors.BOLD}失败详情:{Colors.ENDC}")
            for fail in results["failed"][:5]:  # 最多显示5个失败
                print(f"  • {fail['original']}: {fail['error']}")
        
        # 显示日志文件位置
        print(f"\n📝 详细日志: {os.path.abspath(self.log_file)}")


def interactive_mode():
    """交互式模式 - 用户友好的命令行界面"""
    renamer = FileBatchRenamer()
    
    print(f"{Colors.HEADER}{'='*60}{Colors.ENDC}")
    print(f"{Colors.BOLD}📁 FileBatchRenamer 2.0 - 专业文件批量重命名工具{Colors.ENDC}")
    print(f"{Colors.HEADER}{'='*60}{Colors.ENDC}")
    
    while True:
        print(f"\n{Colors.BOLD}主菜单:{Colors.ENDC}")
        print(f"1️⃣  批量重命名文件")
        print(f"2️⃣  查找重复文件")
        print(f"3️⃣  清理文件名")
        print(f"4️⃣  撤销上一次操作")
        print(f"5️⃣  查看操作日志")
        print(f"6️⃣  退出程序")
        
        choice = input(f"\n{Colors.OKBLUE}请选择操作 (1-6): {Colors.ENDC}").strip()
        
        if choice == "1":
            batch_rename_interactive(renamer)
        elif choice == "2":
            find_duplicates_interactive(renamer)
        elif choice == "3":
            clean_filenames_interactive(renamer)
        elif choice == "4":
            renamer.undo_last_rename()
        elif choice == "5":
            view_logs()
        elif choice == "6":
            print(f"{Colors.OKGREEN}👋 感谢使用 FileBatchRenamer！{Colors.ENDC}")
            break
        else:
            print(f"{Colors.WARNING}⚠️  无效选择，请重新输入{Colors.ENDC}")


def batch_rename_interactive(renamer: FileBatchRenamer):
    """交互式批量重命名"""
    print(f"\n{Colors.BOLD}📁 批量重命名模式{Colors.ENDC}")
    
    # 获取文件夹路径
    folder_path = input(f"{Colors.OKBLUE}请输入文件夹路径: {Colors.ENDC}").strip()
    
    if not os.path.exists(folder_path):
        print(f"{Colors.FAIL}❌ 文件夹不存在{Colors.ENDC}")
        return
    
    # 选择重命名模式
    print(f"\n{Colors.BOLD}请选择重命名模式:{Colors.ENDC}")
    print(f"1. 序列号 (file_001.txt, file_002.txt)")
    print(f"2. 添加日期前缀 (20231225_filename.txt)")
    print(f"3. 替换文本")
    print(f"4. 转为小写")
    print(f"5. 转为大写")
    print(f"6. 移除空格")
    
    mode_choice = input(f"{Colors.OKBLUE}选择模式 (1-6): {Colors.ENDC}").strip()
    
    # 获取文件列表
    recursive = input(f"{Colors.OKBLUE}是否包含子文件夹？(y/n): {Colors.ENDC}").lower() == 'y'
    
    try:
        files = renamer.get_files_list(folder_path, recursive)
        
        if not files:
            print(f"{Colors.WARNING}⚠️  未找到文件{Colors.ENDC}")
            return
        
        print(f"{Colors.OKGREEN}找到 {len(files)} 个文件{Colors.ENDC}")
        
        # 根据模式获取参数
        prefix = suffix = replace_old = replace_new = ""
        rename_pattern = "sequential"
        start_num = 1
        
        if mode_choice == "1":
            rename_pattern = "sequential"
            prefix = input(f"{Colors.OKBLUE}请输入前缀 (直接回车使用默认): {Colors.ENDC}").strip()
            suffix = input(f"{Colors.OKBLUE}请输入后缀 (直接回车跳过): {Colors.ENDC}").strip()
            start_input = input(f"{Colors.OKBLUE}起始序号 (默认1): {Colors.ENDC}").strip()
            start_num = int(start_input) if start_input.isdigit() else 1
            
        elif mode_choice == "2":
            rename_pattern = "date_prefix"
            
        elif mode_choice == "3":
            rename_pattern = "replace"
            replace_old = input(f"{Colors.OKBLUE}要替换的文本: {Colors.ENDC}").strip()
            replace_new = input(f"{Colors.OKBLUE}替换为: {Colors.ENDC}").strip()
            
        elif mode_choice == "4":
            rename_pattern = "lowercase"
            
        elif mode_choice == "5":
            rename_pattern = "uppercase"
            
        elif mode_choice == "6":
            rename_pattern = "remove_spaces"
        
        # 预览重命名
        preview = renamer.preview_rename(
            files, rename_pattern, start_num, prefix, 
            suffix, replace_old, replace_new
        )
        
        print(f"\n{Colors.BOLD}📋 预览重命名结果:{Colors.ENDC}")
        for i, (orig, new_name) in enumerate(preview[:5]):  # 只显示前5个
            print(f"  {orig.name} → {new_name}")
        
        if len(preview) > 5:
            print(f"  ... 还有 {len(preview)-5} 个文件")
        
        # 确认
        confirm = input(f"\n{Colors.WARNING}⚠️  确认执行重命名？(y/n): {Colors.ENDC}").lower()
        
        if confirm == 'y':
            backup = input(f"{Colors.OKBLUE}是否创建备份？(y/n): {Colors.ENDC}").lower() == 'y'
            
            # 执行重命名
            results = renamer.execute_rename(preview, backup)
            renamer.print_summary(results)
        else:
            print(f"{Colors.OKGREEN}操作已取消{Colors.ENDC}")
            
    except Exception as e:
        print(f"{Colors.FAIL}❌ 发生错误: {e}{Colors.ENDC}")


def find_duplicates_interactive(renamer: FileBatchRenamer):
    """交互式查找重复文件"""
    print(f"\n{Colors.BOLD}🔍 查找重复文件{Colors.ENDC}")
    
    folder_path = input(f"{Colors.OKBLUE}请输入文件夹路径: {Colors.ENDC}").strip()
    
    if not os.path.exists(folder_path):
        print(f"{Colors.FAIL}❌ 文件夹不存在{Colors.ENDC}")
        return
    
    try:
        duplicates = renamer.find_duplicate_names(folder_path)
        
        if duplicates:
            print(f"\n{Colors.WARNING}⚠️  找到 {len(duplicates)} 组重复文件:{Colors.ENDC}")
            for i, dup_group in enumerate(duplicates, 1):
                print(f"\n第 {i} 组重复文件:")
                for path in dup_group:
                    print(f"  • {path}")
        else:
            print(f"{Colors.OKGREEN}✅ 未找到重复文件{Colors.ENDC}")
            
    except Exception as e:
        print(f"{Colors.FAIL}❌ 发生错误: {e}{Colors.ENDC}")


def clean_filenames_interactive(renamer: FileBatchRenamer):
    """交互式清理文件名"""
    print(f"\n{Colors.BOLD}🧹 清理文件名{Colors.ENDC}")
    
    folder_path = input(f"{Colors.OKBLUE}请输入文件夹路径: {Colors.ENDC}").strip()
    
    if not os.path.exists(folder_path):
        print(f"{Colors.FAIL}❌ 文件夹不存在{Colors.ENDC}")
        return
    
    try:
        folder = Path(folder_path)
        files = list(folder.iterdir())
        files = [f for f in files if f.is_file()]
        
        print(f"\n找到 {len(files)} 个文件")
        print(f"\n{Colors.BOLD}预览清理结果:{Colors.ENDC}")
        
        preview = []
        for file_path in files[:10]:  # 预览前10个
            clean_name = renamer.clean_filename(file_path.name)
            if clean_name != file_path.name:
                preview.append((file_path, clean_name))
                print(f"  {file_path.name} → {clean_name}")
        
        if not preview:
            print(f"{Colors.OKGREEN}✅ 所有文件名都已符合规范{Colors.ENDC}")
            return
        
        confirm = input(f"\n{Colors.WARNING}⚠️  确认执行清理？(y/n): {Colors.ENDC}").lower()
        
        if confirm == 'y':
            # 执行清理
            results = renamer.execute_rename(preview, backup=True)
            renamer.print_summary(results)
        else:
            print(f"{Colors.OKGREEN}操作已取消{Colors.ENDC}")
            
    except Exception as e:
        print(f"{Colors.FAIL}❌ 发生错误: {e}{Colors.ENDC}")


def view_logs():
    """查看操作日志"""
    log_file = "rename_log.json"
    
    if not os.path.exists(log_file):
        print(f"{Colors.WARNING}⚠️  日志文件不存在{Colors.ENDC}")
        return
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            log_data = json.load(f)
        
        print(f"\n{Colors.BOLD}📝 操作日志 ({len(log_data.get('operations', []))} 条记录){Colors.ENDC}")
        
        for op in log_data.get('operations', [])[-10:]:  # 显示最后10条
            timestamp = op.get('timestamp', '未知时间')
            operation = op.get('operation', '未知操作')
            
            print(f"\n{Colors.OKBLUE}[{timestamp}] {operation}{Colors.ENDC}")
            
            if operation == "batch_rename":
                details = op.get('details', {})
                print(f"  文件数: {details.get('total_files', 0)}")
                print(f"  成功: {details.get('successful', 0)}")
                print(f"  失败: {details.get('failed', 0)}")
                if details.get('backup_path'):
                    print(f"  备份: {details['backup_path']}")
                    
    except Exception as e:
        print(f"{Colors.FAIL}❌ 读取日志失败: {e}{Colors.ENDC}")


def command_line_mode():
    """命令行模式 - 适合自动化脚本"""
    parser = argparse.ArgumentParser(
        description='专业文件批量重命名工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 基本重命名
  python file_renamer.py ./photos --prefix "vacation_" --sequential
  
  # 添加日期前缀
  python file_renamer.py ./docs --date-prefix
  
  # 替换文本
  python file_renamer.py ./files --replace "old" "new"
  
  # 预览模式（不实际执行）
  python file_renamer.py ./files --prefix "new_" --dry-run
  
  # 递归处理子文件夹
  python file_renamer.py ./project --recursive --lowercase
        """
    )
    
    parser.add_argument('path', help='文件夹路径')
    parser.add_argument('--prefix', help='添加前缀')
    parser.add_argument('--suffix', help='添加后缀')
    parser.add_argument('--sequential', action='store_true', help='使用序列号')
    parser.add_argument('--start', type=int, default=1, help='序列号起始值')
    parser.add_argument('--digits', type=int, default=3, help='序列号位数')
    parser.add_argument('--date-prefix', action='store_true', help='添加日期前缀')
    parser.add_argument('--replace', nargs=2, metavar=('OLD', 'NEW'), help='替换文本')
    parser.add_argument('--lowercase', action='store_true', help='转为小写')
    parser.add_argument('--uppercase', action='store_true', help='转为大写')
    parser.add_argument('--remove-spaces', action='store_true', help='移除空格')
    parser.add_argument('--recursive', '-r', action='store_true', help='递归处理子文件夹')
    parser.add_argument('--dry-run', action='store_true', help='预览模式（不实际执行）')
    parser.add_argument('--no-backup', action='store_true', help='不创建备份')
    parser.add_argument('--extensions', nargs='+', help='只处理指定扩展名')
    parser.add_argument('--interactive', '-i', action='store_true', help='交互式模式')
    
    args = parser.parse_args()
    
    if args.interactive:
        interactive_mode()
        return
    
    renamer = FileBatchRenamer()
    renamer.dry_run = args.dry_run
    
    try:
        # 获取文件列表
        files = renamer.get_files_list(args.path, args.recursive, args.extensions)
        
        if not files:
            print(f"{Colors.WARNING}⚠️  未找到文件{Colors.ENDC}")
            return
        
        print(f"{Colors.OKGREEN}找到 {len(files)} 个文件{Colors.ENDC}")
        
        # 确定重命名模式
        rename_pattern = "default"
        replace_old = replace_new = ""
        
        if args.sequential:
            rename_pattern = "sequential"
        elif args.date_prefix:
            rename_pattern = "date_prefix"
        elif args.replace:
            rename_pattern = "replace"
            replace_old, replace_new = args.replace
        elif args.lowercase:
            rename_pattern = "lowercase"
        elif args.uppercase:
            rename_pattern = "uppercase"
        elif args.remove_spaces:
            rename_pattern = "remove_spaces"
        
        # 预览重命名
        preview = renamer.preview_rename(
            files, rename_pattern, args.start, 
            args.prefix or "", args.suffix or "",
            replace_old, replace_new
        )
        
        # 显示预览
        print(f"\n{Colors.BOLD}📋 预览结果:{Colors.ENDC}")
        for orig, new_name in preview[:5]:
            print(f"  {orig.name} → {new_name}")
        
        if len(preview) > 5:
            print(f"  ... 还有 {len(preview)-5} 个文件")
        
        if args.dry_run:
            print(f"\n{Colors.WARNING}⚠️  预览模式 - 不会实际重命名文件{Colors.ENDC}")
            return
        
        # 执行重命名
        confirm = input(f"\n{Colors.WARNING}⚠️  确认执行？(y/n): {Colors.ENDC}").lower()
        
        if confirm == 'y':
            backup = not args.no_backup
            results = renamer.execute_rename(preview, backup)
            renamer.print_summary(results)
        else:
            print(f"{Colors.OKGREEN}操作已取消{Colors.ENDC}")
            
    except Exception as e:
        print(f"{Colors.FAIL}❌ 错误: {e}{Colors.ENDC}")
        sys.exit(1)


if __name__ == "__main__":
    # 自动检测运行模式
    if len(sys.argv) > 1:
        # 命令行模式
        command_line_mode()
    else:
        # 交互式模式
        interactive_mode()