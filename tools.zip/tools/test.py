# test_config.py - 测试配置是否生效
import json
import os

print("=== 测试配置文件 ===")

# 检查文件是否存在
config_file = "renamer_config.json"
if os.path.exists(config_file):
    print(f"✅ 配置文件存在: {os.path.abspath(config_file)}")
    
    # 读取并显示配置
    with open(config_file, "r", encoding="utf-8") as f:
        config = json.load(f)
    
    print(f"\n📋 配置摘要:")
    print(f"- 默认前缀: {config.get('default_prefix', '未设置')}")
    print(f"- 备份功能: {'开启' if config.get('backup_before_rename') else '关闭'}")
    print(f"- 支持扩展名: {len(config.get('supported_extensions', []))} 种")
    print(f"- 日志级别: {config.get('log_level', '未设置')}")
    
    # 显示部分扩展名
    extensions = config.get('supported_extensions', [])
    if extensions:
        print(f"\n📁 支持的文件类型（前5个）:")
        for ext in extensions[:5]:
            print(f"  • {ext}")
        if len(extensions) > 5:
            print(f"  等共 {len(extensions)} 种格式")
else:
    print(f"❌ 配置文件不存在，将使用内置默认配置")
    
print("\n📌 提示: 你可以修改 renamer_config.json 来自定义工具行为")