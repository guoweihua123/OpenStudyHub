"""
番茄钟学习计时器
功能：25分钟学习 + 5分钟休息的循环计时器
"""

import time
import sys
import os

def pomodoro_timer(work_minutes=25, break_minutes=5, cycles=4):
    """
    执行番茄钟计时
    :param work_minutes: 学习时长（分钟）
    :param break_minutes: 休息时长（分钟）
    :param cycles: 循环次数
    """
    print(f"🍅 番茄钟计时器启动！")
    print(f"📚 学习: {work_minutes}分钟 | 🧘 休息: {break_minutes}分钟")
    print(f"🔄 计划完成 {cycles} 个循环\n")
    
    for cycle in range(1, cycles + 1):
        print(f"\n=== 第 {cycle}/{cycles} 个循环 ===")
        
        # 学习时间
        print(f"⏰ 开始学习 ({work_minutes}分钟)...")
        countdown(work_minutes * 60, "学习")
        
        if cycle < cycles:
            # 短暂休息
            print(f"☕ 休息时间 ({break_minutes}分钟)...")
            countdown(break_minutes * 60, "休息")
        else:
            print("🎉 恭喜！所有番茄钟完成！")
    
    print("\n⭐ 今日学习任务完成！继续保持！")

def countdown(seconds, mode):
    """倒计时显示"""
    try:
        for remaining in range(seconds, 0, -1):
            mins, secs = divmod(remaining, 60)
            time_display = f"{mins:02d}:{secs:02d}"
            
            # 进度条（每5秒更新一次）
            if remaining % 5 == 0:
                progress = int((seconds - remaining) / seconds * 30)
                bar = "█" * progress + "░" * (30 - progress)
                percent = int((seconds - remaining) / seconds * 100)
                sys.stdout.write(f"\r[{bar}] {time_display} - {mode}中... {percent}% ")
                sys.stdout.flush()
            
            time.sleep(1)
        
        print(f"\r[{'█'*30}] 00:00 - {mode}结束！{' '*20}")
        
        # 计时结束提示音（系统提示音）
        print("\a")
        
    except KeyboardInterrupt:
        print(f"\n⏹️  {mode}被中断")
        raise

if __name__ == "__main__":
    print("=== 番茄钟学习计时器 ===")
    
    try:
        # 用户自定义设置
        custom = input("使用默认设置？(25/5/4) (y/n): ").lower()
        
        if custom == 'n':
            work = int(input("学习时长（分钟）: "))
            break_time = int(input("休息时长（分钟）: "))
            cycles = int(input("循环次数: "))
            pomodoro_timer(work, break_time, cycles)
        else:
            # 默认设置
            pomodoro_timer()
            
    except ValueError:
        print("请输入有效的数字！")
    except KeyboardInterrupt:
        print("\n👋 已退出番茄钟计时器")